
var test_mode = true;
var battle_speed = 0.65;

var card_drop_chance_reduction = 4;

var king_battle_timeout = 60;