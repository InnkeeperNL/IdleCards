var all_offers = {
	peasant:{
		shop_type: 			'scrap',
		costs:{
			scraps: 		10,
		},
		result: 			'peasant',
		amount: 			1,
	},
	/*stash:{
		shop_type: 			'scrap',
		costs:{
			scraps: 		100,
		},
		result: 			'stash',
		amount: 			1,
	},
	trunk:{
		shop_type: 			'scrap',
		costs:{
			scraps: 		500,
		},
		result: 			'trunk',
		amount: 			1,
	},
	spellbook:{
		shop_type: 			'scrap',
		costs:{
			scraps: 		500,
		},
		result: 			'spellbook',
		amount: 			1,
	},
	unidentified_artifact:{
		shop_type: 			'scrap',
		costs:{
			scraps: 		500,
		},
		result: 			'unidentified_artifact',
		amount: 			1,
	},
	chick_trunk:{
		shop_type: 			'scrap',
		months_available: 	[5],
		costs:{
			chick: 			10,
		},
		result: 			'trunk',
		amount: 			1,
	},
	chick_chest:{
		shop_type: 			'scrap',
		months_available: 	[5],
		costs:{
			chick: 			50,
			scraps: 		1000,
		},
		result: 			'chest',
		amount: 			1,
	},
	easter_eggs_trunk:{
		shop_type: 			'scrap',
		months_available: 	[4],
		costs:{
			easter_eggs: 	10,
		},
		result: 			'trunk',
		amount: 			1,
	},
	easter_eggs_chest:{
		shop_type: 			'scrap',
		months_available: 	[4],
		costs:{
			easter_eggs: 	50,
			scraps: 		1000,
		},
		result: 			'chest',
		amount: 			1,
	},
	
	hearts_trunk:{
		shop_type: 			'scrap',
		months_available: 	[2],
		costs:{
			hearts: 		10,
		},
		result: 			'trunk',
		amount: 			1,
	},
	hearts_chest:{
		shop_type: 			'scrap',
		months_available: 	[2],
		costs:{
			hearts: 		50,
			scraps: 		1000,
		},
		result: 			'chest',
		amount: 			1,
	},
	snowdrops_trunk:{
		shop_type: 			'scrap',
		months_available: 	[3],
		costs:{
			snowdrops: 		10,
		},
		result: 			'trunk',
		amount: 			1,
	},
	snowdrops_chest:{
		shop_type: 			'scrap',
		months_available: 	[3],
		costs:{
			snowdrops: 		50,
			scraps: 		1000,
		},
		result: 			'chest',
		amount: 			1,
	},*/
	
}