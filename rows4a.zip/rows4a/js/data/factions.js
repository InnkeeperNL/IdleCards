var all_factions = {
};

all_factions = sortObj(all_factions);