var available_items = {
	
	ship:{
		name: 		'ship',
		value: 		2500,
		image: 		'items/galleon-1572636_640.jpg',
		rarity: 	3,
	},
	fishing_ship:{
		name: 		'fishing ship',
		value: 		4000,
		image: 		'items/ship-2904969_640.jpg',
		rarity: 	3,
	},
	
	apple:{
		name: 		'apple',
		value: 		5,
		image: 		'items/apple-1589874_640.jpg',
		rarity: 	2,
	},
	milk:{
		name: 		'milk',
		value: 		5,
		image: 		'items/milk-2777165_640.jpg',
		rarity: 	2,
	},
	butter:{
		name: 		'butter',
		value: 		25,
		image: 		'items/food-3179853_640.jpg',
		rarity: 	2,
	},
	
	rennet:{
		name: 		'rennet',
		value: 		20,
		image: 		'items/liquor-1496358_640.jpg',
		rarity: 	1,
	},
	cheese:{
		name: 		'cheese',
		value: 		150,
		image: 		'items/cheese-3463368_640.jpg',
		rarity: 	2,
	},
	
	cow:{
		name: 		'cow',
		value: 		150,
		image: 		'items/cow-431729_640.jpg',
		stats:{
			hit: 		2,
			power: 		5,
			evade: 		0,
			armor: 		0,
			health: 	250,
			abilities:{
				strike: 	1
			},
		}
	},
	horse:{
		name: 		'horse',
		value: 		450,
		image: 		'items/horse-197199_640.jpg',
		rarity: 	2,
		stats:{
			hit: 		5,
			power: 		7,
			evade: 		5,
			armor: 		0,
			health: 	200,
			abilities:{
				strike: 	1
			},
		}
	},
	sheep:{
		name: 		'sheep',
		value: 		100,
		image: 		'items/ireland-1985088_640.jpg',
		stats:{
			hit: 		2,
			power: 		1,
			evade: 		5,
			armor: 		0,
			health: 	100,
			abilities:{
				strike: 	1
			},
		}
	},
	wool:{
		name: 		'wool',
		value: 		20,
		image: 		'items/yarn-2564556_640.jpg',
	},
	twine:{
		name: 		'twine',
		value: 		20,
		image: 		'items/abstract-21764_640.jpg',
	},
	
	
	cloth:{
		name: 		'cloth',
		value: 		100,
		image: 		'items/towel-1838210_640.jpg',
	},
	sack:{
		name: 		'sack',
		value: 		150,
		image: 		'items/child-1939031_640.jpg',
		
	},
	bandage:{
		name: 		'bandage',
		value: 		600,
		image: 		'items/gauze-3902918_640.jpg',
		rarity: 	2,
	},
	remedy:{
		name: 		'remedy',
		value: 		500,
		image: 		'items/calendula-6512323_1280.jpg',
		rarity: 	2,
	},
	first_aid_kit:{
		name: 		'first aid kit',
		value: 		9000,
		image: 		'items/mine-1217744_1280.jpg',
		rarity: 	3,
	},
	cloak:{
		name: 		'cloak',
		value: 		1000,
		image: 		'items/man-962563_640.jpg',
		rarity: 	2,
	},
	
	hide:{
		name: 		'hide',
		value: 		15,
		image: 		'items/deer-hide-58889_640.jpg',
	},
	leather:{
		name: 		'leather',
		value: 		75,
		image: 		'items/leather-540142_640.jpg',
	},
	boots:{
		name: 		'boots',
		value: 		500,
		image: 		'items/boots-1853964_640.jpg',
		rarity: 	2,
	},
	saddle:{
		name: 		'saddle',
		value: 		625,
		image: 		'items/cowboy-saddle-2345137_640.jpg',
		rarity: 	2,
	},
	
	sand:{
		name: 		'sand',
		value: 		2,
		image: 		'items/sand-5415920_640.jpg',
	},
	glass:{
		name: 		'glass',
		value: 		30,
		image: 		'items/window-223770_640.jpg',
	},
	clay:{
		name: 		'clay',
		value: 		10,
		image: 		'items/background-3362171_640.jpg',
	},
	brick:{
		name: 		'brick',
		value: 		50,
		image: 		'items/brick-164959_640.jpg',
	},
	shingle:{
		name: 		'shingle',
		value: 		50,
		image: 		'items/roof-1009158_640.jpg',
	},
	wall:{
		name: 		'wall',
		value: 		500,
		image: 		'items/wall-of-bricks-336546_640.jpg',
	},
	house:{
		name: 		'house',
		value: 		3150,
		image: 		'items/home-timber-framed-2664261_640.jpg',
		rarity: 	2,
	},
	peasant:{
		name: 		'peasant',
		value: 		20,
		image: 		'items/peasant-482727_640.jpg',
		stats:{
			hit: 		1,
			power: 		2,
			evade: 		0,
			armor: 		0,
			health: 	70,
			abilities:{
				strike: 	1
			},
		}
	},
	farmer:{
		name: 		'farmer',
		value: 		250,
		image: 		'items/labor-1406652_640.jpg',
		stats:{
			hit: 		2,
			power: 		3,
			evade: 		2,
			armor: 		0,
			health: 	120,
			abilities:{
				strike: 	1
			},
		}
	},
	fisherman:{
		name: 		'fisherman',
		value: 		125,
		image: 		'items/fisherman-5970480_640.jpg',
		stats:{
			hit: 		2,
			power: 		2,
			evade: 		1,
			armor: 		0,
			health: 	200,
			abilities:{
				strike: 	1
			},
		}
	},
	
	thief:{
		name: 		'thief',
		value: 		3000,
		image: 		'items/woman-2545577_640.jpg',
		stats:{
			hit: 		10,
			power: 		11,
			evade: 		10,
			armor: 		0,
			health: 	500,
			abilities:{
				strike: 	1
			},
		}
	},
	cowboy:{
		name: 		'cowboy',
		value: 		2500,
		image: 		'items/rodeo-515612_640.jpg',
		stats:{
			hit: 		8,
			power: 		14,
			evade: 		8,
			armor: 		0,
			health: 	500,
			abilities:{
				strike: 	1
			},
		}
	},
	
	carp:{
		name: 		'carp',
		value: 		10,
		image: 		'items/fish-1710231_640.jpg',
	},
	perch:{
		name: 		'perch',
		value: 		10,
		image: 		'items/fish-730497_640.jpg',
	},
	trout:{
		name: 		'trout',
		value: 		20,
		image: 		'items/fish-4581261_640.jpg',
	},
	
	salmon:{
		name: 		'salmon',
		value: 		40,
		image: 		'items/salmon-4143734_640.jpg',
	},
	eel:{
		name: 		'eel',
		value: 		80,
		image: 		'items/fish-15089_640.jpg',
	},
	
	smoked_fish:{
		name: 		'smoked fish',
		value: 		100,
		image: 		'items/char-2258284_640.jpg',
		rarity: 	2,
	},
	cooked_eel:{
		name: 		'cooked eel',
		value: 		220,
		image: 		'items/eel-2817257_640.jpg',
		rarity: 	2,
	},
	
	cooked_salmon:{
		name: 		'cooked salmon',
		value: 		150,
		image: 		'items/salmon-6037073_640.jpg',
		rarity: 	2,
	},
	grilled_trout:{
		name: 		'grilled trout',
		value: 		90,
		image: 		'items/fish-5038952_640.jpg',
		rarity: 	2
	},
	roasted_perch:{
		name: 		'roasted perch',
		value: 		50,
		image: 		'items/fish-5656366_640.jpg',
		rarity: 	2,
	},
	
	perch_and_potatoes:{
		name: 		'perch and potatoes',
		value: 		200,
		image: 		'items/fish-4469926_640.jpg',
		rarity: 	2,
	},
	fries:{
		name: 		'fries',
		value: 		80,
		image: 		'items/french-fries-923687_640.jpg',
		rarity: 	2,
	},
	
	lumber:{
		name: 		'lumber',
		value: 		10,
		image: 		'items/logs-3639211_640.jpg',
	},
	hardwood:{
		name: 		'hardwood',
		value: 		500,
		image: 		'items/background-89200_640.jpg',
		rarity: 	3,
	},
	water:{
		name: 		'water',
		value: 		2,
		image: 		'items/bubbles-230014_640.jpg',
	},
	firewood:{
		name: 		'firewood',
		value: 		2,
		image: 		'items/wood-1079365_640.jpg',
	},
	leaves:{
		name: 		'leaves',
		value: 		2,
		image: 		'items/autumn-111315_640.jpg',
	},
	
	grass:{
		name: 		'grass',
		value: 		2,
		image: 		'items/dew-1507498_640.jpg',
	},
	hay:{
		name: 		'hay',
		value: 		10,
		image: 		'items/background-1474292_640.jpg',
	},
	hay_bale:{
		name: 		'hay bale',
		value: 		50,
		image: 		'items/bale-3026360_640.jpg',
	},
	pole:{
		name: 		'pole',
		value: 		20,
		image: 		'items/rods-53130_640.jpg',
	},
	plank:{
		name: 		'plank',
		value: 		50,
		image: 		'items/board-2941888_640.jpg',
	},
	crate:{
		name: 		'crate',
		value: 		150,
		image: 		'items/box-2064180_640.jpg',
		rarity: 	2,
	},
	barrel:{
		name: 		'barrel',
		value: 		150,
		image: 		'items/wooden-258622_640.jpg',
		rarity: 	2,
	},
	bed:{
		name: 		'bed',
		value: 		700,
		image: 		'items/old-house-3594537_640.jpg',
		rarity: 	2,
	},
	
	cart:{
		name: 		'cart',
		value: 		825,
		image: 		'items/cart-1007949_640.jpg',
		rarity: 	1,
	},
	
	supplies:{
		name: 		'supplies',
		value: 		1000,
		image: 		'items/boxes-2719166_640.jpg',
		rarity: 	2,
	},
	treasure:{
		name: 		'treasure',
		value: 		10000,
		image: 		'items/treasure-chest-619762_640.jpg',
		rarity: 	4,
	},
	
	stone:{
		name: 		'stone',
		value: 		5,
		image: 		'items/stones-81233_640.jpg',
	},
	copper_ore:{
		name: 		'copper ore',
		value: 		20,
		image: 		'items/copper-ore-1008566_640.jpg',
	},
	copper:{
		name: 		'copper',
		value: 		30,
		image: 		'items/wire-2681887_640.jpg',
	},
	coal:{
		name: 		'coal',
		value: 		10,
		image: 		'items/coal-1626368_640.jpg',
	},
	salt:{
		name: 		'salt',
		value: 		10,
		image: 		'items/salt-602215_640.jpg',
	},
	iron_ore:{
		name: 		'iron ore',
		value: 		30,
		image: 		'items/meteorite-91891_640.jpg',
	},
	iron:{
		name: 		'iron',
		value: 		50,
		image: 		'items/iron-rods-474800_640.jpg',
	},
	nails:{
		name: 		'nails',
		value: 		5,
		image: 		'items/nails-4168539_640.jpg',
	},
	plate_armor:{
		name: 		'plate armor',
		value: 		350,
		image: 		'items/knight-1283910_640.jpg',
		rarity: 	2,
	},
	shield:{
		name: 		'shield',
		value: 		250,
		image: 		'items/shield-499839_640.jpg',
		rarity: 	2,
	},
	guard:{
		name: 		'guard',
		value: 		1400,
		image: 		'items/knight-1813084_640.jpg',
		stats:{
			hit: 		3,
			power: 		4,
			evade: 		3,
			armor: 		5,
			health: 	250,
			abilities:{
				strike: 	1
			},
		}
	},
	
	silver_ore:{
		name: 		'silver ore',
		value: 		100,
		image: 		'items/outstanding-1436005_640.jpg',
	},
	silver:{
		name: 		'silver',
		value: 		200,
		image: 		'items/bullion-932218_640.jpg',
		rarity: 	2,
	},
	silver_ring:{
		name: 		'silver ring',
		value: 		500,
		image: 		'items/silver-ring-2231967_640.jpg',
		rarity: 	3,
	},
	gold_ore:{
		name: 		'gold ore',
		value: 		250,
		image: 		'items/stone-194822_640.jpg',
	},
	gold:{
		name: 		'gold',
		value: 		500,
		image: 		'items/gold-513062_640.jpg',
		rarity: 	2,
	},
	gold_ring:{
		name: 		'gold ring',
		value: 		1200,
		image: 		'items/wedding-ring-4549875_640.jpg',
		rarity: 	3,
	},
	
	lettuce:{
		name: 		'lettuce',
		value: 		5,
		image: 		'items/green-1710328_640.jpg',
	},
	cucumber:{
		name: 		'cucumber',
		value: 		8,
		image: 		'items/cucumbers-849269_640.jpg',
	},
	tomato:{
		name: 		'tomato',
		value: 		10,
		image: 		'items/tomatoes-4238247_640.jpg',
	},
	carrot:{
		name: 		'carrot',
		value: 		25,
		image: 		'items/carrot-1565597_640.jpg',
	},
	potato:{
		name: 		'potato',
		value: 		20,
		image: 		'items/potatoes-1585060_640.jpg',
	},
	onion:{
		name: 		'onion',
		value: 		20,
		image: 		'items/onions-1397037_640.jpg',
	},
	onion_rings:{
		name: 		'onion rings',
		value: 		100,
		image: 		'items/food-3669928_640.jpg',
		rarity: 2,
	},
	sugarcane:{
		name: 		'sugarcane',
		value: 		20,
		image: 		'items/sugarcane-5388614_640.jpg',
	},
	sugar:{
		name: 		'sugar',
		value: 		40,
		image: 		'items/sugar-1354787_640.jpg',
	},
	wheat:{
		name: 		'wheat',
		value: 		5,
		image: 		'items/wheat-3241114_640.jpg',
	},
	flax:{
		name: 		'flax',
		value: 		5,
		image: 		'items/nature-3082560_640.jpg',
	},
	
	meat:{
		name: 		'meat',
		value: 		40,
		image: 		'items/steak-1081819_640.jpg',
	},
	hamburger:{
		name: 		'hamburger',
		value: 		300,
		image: 		'items/burger-3442227_640.jpg',
		rarity: 	2,
	},
	
	steak:{
		name: 		'steak',
		value: 		150,
		image: 		'items/steak-2272464_640.jpg',
		rarity: 	2,
	},
	steak_dinner:{
		name: 		'steak dinner',
		value: 		1250,
		image: 		'items/steak-881170_640.jpg',
		rarity: 	2,
	},
	
	salad:{
		name: 		'salad',
		value: 		50,
		image: 		'items/salad-1812349_640.jpg',
		rarity: 	2,
	},
	tomato_soup:{
		name: 		'tomato soup',
		value: 		250,
		image: 		'items/food-786108_640.jpg',
		rarity: 	2,
	},
	
	bread:{
		name: 		'bread',
		value: 		70,
		image: 		'items/bread-1281053_640.jpg',
		rarity: 	2,
	},
	cucumber_sandwich:{
		name: 		'cucumber sandwich',
		value: 		150,
		image: 		'items/cucumber-2047267_640.jpg',
		rarity: 	2,
	},
	flour:{
		name: 		'flour',
		value: 		25,
		image: 		'items/wheat-5416898_640.jpg',
	},
	egg:{
		name: 		'egg',
		value: 		5,
		image: 		'items/nest-1050964_640.jpg',
	},
	feather:{
		name: 		'feather',
		value: 		2,
		image: 		'items/feather-2709789_640.jpg',
	},
	
	pillow:{
		name: 		'pillow',
		value: 		200,
		image: 		'items/pillows-655245_640.jpg',
		rarity: 	1
	},
	arrow:{
		name: 		'arrow',
		value: 		6,
		image: 		'items/arrows-4082046_640.jpg',
	},
	
	hunter:{
		name: 		'hunter',
		value: 		180,
		image: 		'items/archer-3895735_640.jpg',
		stats:{
			hit: 		3,
			power: 		2,
			evade: 		2,
			armor: 		0,
			health: 	120,
			abilities:{
				strike: 	1
			},
		}
	},
	veteran_hunter:{
		name: 		'veteran hunter',
		value: 		2000,
		image: 		'items/woman-3353689_640.jpg',
		stats:{
			hit: 		3,
			power: 		2,
			evade: 		2,
			armor: 		0,
			health: 	120,
			abilities:{
				strike: 	1
			},
		}
	},
	
	miner:{
		name: 		'miner',
		value: 		250,
		image: 		'items/dwarf-5693899_640.jpg',
		stats:{
			hit: 		1,
			power: 		2,
			evade: 		1,
			armor: 		2,
			health: 	170,
			abilities:{
				strike: 	1
			},
		}
	},
	lumberjack:{
		name: 		'lumberjack',
		value: 		250,
		image: 		'items/wood-4248997_640.jpg',
		stats:{
			hit: 		3,
			power: 		2,
			evade: 		2,
			armor: 		0,
			health: 	120,
			abilities:{
				strike: 	1
			},
		}
	},

	bow:{
		name: 		'bow',
		value: 		90,
		image: 		'items/arrow-1557462_640.jpg',
		rarity: 	2,
	},
	apple_pie:{
		name: 		'apple pie',
		value: 		645,
		image: 		'items/apple-pie-5479993_640.jpg',
		rarity: 	3,
	},
	copper_pot:{
		name: 		'copper pot',
		value: 		80,
		image: 		'items/water-boiler-4604072_640.jpg',
		rarity: 	2,
	},
	knife:{
		name: 		'knife',
		value: 		120,
		image: 		'items/nature-5325518_640.jpg',
		rarity: 	2,
	},
	sinister_dagger:{
		name: 		'sinister dagger',
		value: 		1000,
		image: 		'items/spook-5987623_640.jpg',
		rarity: 	3,
	},
	axe:{
		name: 		'axe',
		value: 		140,
		image: 		'items/axe-674841_640.jpg',
		rarity: 	2,
	},
	plow:{
		name: 		'plow',
		value: 		200,
		image: 		'items/plow-1379734_640.jpg',
		rarity: 	2,
	},
	spear:{
		name: 		'spear',
		value: 		140,
		image: 		'items/middle-ages-228656_640.jpg',
		rarity: 	2,
	},
	pitchfork:{
		name: 		'pitchfork',
		value: 		140,
		image: 		'items/background-2659339_640.jpg',
		rarity: 	2,
	},
	pickaxe:{
		name: 		'pickaxe',
		value: 		140,
		image: 		'items/pickaxe-5070026_640.jpg',
		rarity: 	2,
	},
	net:{
		name: 		'net',
		value: 		60,
		image: 		'items/fishing-nets-3341187_640.jpg',
		rarity: 	2,
	},
	parsley:{
		name: 		'parsley',
		value: 		5,
		image: 		'items/parsley-261039_640.jpg',
	},
	mint:{
		name: 		'mint',
		value: 		10,
		image: 		'items/mint-1500452_640.jpg',
	},
	mint_tea:{
		name: 		'mint tea',
		value: 		110,
		image: 		'items/peppermint-2816233_640.jpg',
		rarity: 	2,
	},
	sage:{
		name: 		'sage',
		value: 		25,
		image: 		'items/sage-1544883_640.jpg',
	},
	rosemary:{
		name: 		'rosemary',
		value: 		50,
		image: 		'items/rosemary-1409060_640.jpg',
	},
	health_potion:{
		name: 		'health potion',
		value: 		100,
		image: 		'items/macro-4924607_640.jpg',
		rarity: 	2,
	},
	mana_potion:{
		name: 		'mana potion',
		value: 		300,
		image: 		'items/macro-4924607_640l.jpg',
		rarity: 	2,
	},
	poison:{
		name: 		'poison',
		value: 		350,
		image: 		'items/bottle-1481599_640.jpg',
		rarity: 	2,
	},
	love_potion:{
		name: 		'love potion',
		value: 		550,
		image: 		'items/purple-3102305_640.jpg',
		rarity: 	3,
	},
	restore_potion:{
		name: 		'restore potion',
		value: 		1200,
		image: 		'items/smoothie-3176355_640.jpg',
		rarity: 	3,
	},
	bone:{
		name: 		'bone',
		value: 		20,
		image: 		'items/bone-664596_640.jpg',
		rarity: 	1
	},
	chicken:{
		name: 		'chicken',
		value: 		50,
		image: 		'items/hen-451984_640.jpg',
		stats:{
			hit: 		1,
			power: 		1,
			evade: 		3,
			armor: 		0,
			health: 	100,
			abilities:{
				strike: 	1
			},
		}
	},
	rooster:{
		name: 		'rooster',
		value: 		100,
		image: 		'items/rooster-1284283_640.jpg',
		stats:{
			hit: 		2,
			power: 		2,
			evade: 		3,
			armor: 		0,
			health: 	100,
			abilities:{
				strike: 	1
			},
		}
	},
	
}

$.each(available_items, function(item_id, item_info){
	item_info['value'] *= 10;
});

available_items = sortObj(available_items);

available_items = true_sort_object(available_items, 'value', false);

$.each(available_actions, function(action_id, action_info){
	if(action_info['type'] == undefined || action_info['type'] == 'basic')
	{
		var total_value = 0;
		if(action_info['item_id'] != undefined)
		{
			total_value += available_items[action_info['item_id']]['value'];
		}
		$.each(action_info['bonus_loot'], function(bonus_id, bonus_chance){
			if(available_items[bonus_id] != undefined)
			{
				total_value += (available_items[bonus_id]['value'] * bonus_chance / 100);
			}
		});

		if(action_info['reward_factor'] != undefined)
		{
			total_value = total_value * action_info['reward_factor'];
		}
		
		var full_value = total_value + 0;

		if(action_info['cost'] != undefined)
		{
		/*	
			action_info['chance'] = (50 / total_value);
		}
		else
		{*/
			var total_cost = 0;
			
			$.each(action_info['cost'], function(cost_id, cost_amount){
				if(available_items[cost_id] != undefined)
				{
					total_cost += available_items[cost_id]['value'] * cost_amount;
				}
			});
			if(total_cost > 0)
			{
				//action_info['chance'] = action_info['chance'] * (1 + ((total_cost * 2) / total_value));
				total_value -= total_cost;
			}
			//action_info['chance'] = (50 / (total_value / (1 + (total_value / 1000))));
			/*if(total_cost > 0 && total_cost > total_value)
			{
				action_info['chance'] *= total_cost / total_value;
				//action_info['result_amount'] = Math.ceil(total_cost / available_items[action_info['item_id']]['value']);
			}
			if(total_cost > 0 && total_cost < total_value)
			{
				if(total_cost / total_value < 0.5)
				{
					action_info['chance'] *= 0.5;
				}
				else
				{
					action_info['chance'] *= total_cost / total_value;
				}
				
			}*/
			if(total_cost / full_value < 0.6)
			{
				//console.log(action_id + ' cost to low: ' + Math.floor((total_cost / full_value * 10)) / 10);
			}
			if(total_cost / full_value >= 1)
			{
				console.log(action_id + ' cost to high!!! ' + Math.floor((total_cost / full_value * 10)) / 10);
			}
			var cost_factor = total_cost / full_value;
			/*if(total_cost / full_value >= 0.6 && total_cost / full_value < 1)
			{
				console.log('GOOD: ' + action_id + ': ' + Math.floor((total_cost / full_value * 10)) / 10);
			}*/
			var effective_value = full_value - (total_cost * (1 + (count_object(action_info['cost']) / 10)));
			if(effective_value < 10)
			{
				console.log(action_id + ' cost to high!!! ' + effective_value);
				effective_value = 10;
			}
			action_info['chance'] = (100 / effective_value /*(full_value / (1 + (cost_factor * 2)))*/);
		}
		else
		{
			action_info['chance'] = (100 / total_value);
		}
		
		if(action_info['upgrade_item'] != undefined)
		{
			var upgrade_effect = (Math.sqrt(available_items[action_info['upgrade_item']]['value']) / 15);
			if(upgrade_effect < 1){upgrade_effect = 1;}
			action_info['passive_factor'] = upgrade_effect;
		}
		if(action_info['passive_factor'] == undefined)
		{
			action_info['passive_factor'] = 1;
		}
		if(action_info['progress_needed'] == undefined)
		{
			action_info['progress_needed'] = 1;
		}
		if(action_info['progress_needed'] != undefined)
		{
			action_info['chance'] *= action_info['progress_needed'];
		}
		
		

	}
});