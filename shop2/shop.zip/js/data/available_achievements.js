var available_achievements = {
	/*firewood: {
		name: 	'firewood',
		background_item: 	'firewood',
		amount: 		10,
		amount_facor: 	2,
		item_procs: 	{
			firewood: 	true,
		},
		skill_procs:{

		},
		item_bonus:{
			firewood: 	1,
		},
		skill_bonus:{

		}
	},
	training: {
		name: 	'training',
		background_item: 	'peasant',
		amount: 		10,
		amount_facor: 	2,
		item_procs: 	{
		},
		skill_procs:{
			training: 	true,
		},
		item_bonus:{
		},
		skill_bonus:{
			training: 	5,
		}
	},*/
}

$.each(available_items, function(item_id, item_info){
	if(available_achievements[item_id] == undefined){
		available_achievements[item_id] = {
			name: 	'' + item_info['name'],
			text: 	'Collect ' + item_info['name'],
			background_item: 	item_id + '',
			amount: 		1000,
			amount_facor: 	10,
			item_procs: 	{},
			skill_procs:{},
			item_bonus:{},
			skill_bonus:{}
		};
		available_achievements[item_id]['item_procs'][item_id] = true;
		available_achievements[item_id]['item_bonus'][item_id] = 10;
	}
});

$.each(available_skills, function(skill_id, skill_info){
	if(available_achievements[skill_id] == undefined){
		available_achievements[skill_id] = {
			name: 	'' + skill_id,
			text: 	'Perform actions using the ' + skill_id + ' skill',
			background_item: 	'',
			amount: 		10000,
			amount_facor: 	10,
			item_procs: 	{},
			skill_procs:{},
			item_bonus:{},
			skill_bonus:{}
		};
		available_achievements[skill_id]['skill_procs'][skill_id] = true;
		available_achievements[skill_id]['skill_bonus'][skill_id] = 10;
	}
});

available_achievements = sortObj(available_achievements);

var available_ap_bonusses = {
	chef: {
		name: 	'chef',
		text: 	'Get 25% more items from cooking each level.',
		background_item: 	'hamburger',
		cost: 			5,
		item_bonus:{
		},
		skill_bonus:{
			cooking: 	25,
		}
	},
	lumberjack: {
		name: 	'lumberjack',
		text: 	'Get 25% more lumber, firewood and hardwood each level.',
		background_item: 	'lumberjack',
		cost: 			2,
		item_bonus:{
			firewood: 	25,
			lumber: 	25,
			hardwood: 	25
		},
		skill_bonus:{
		}
	},
	haymaker: {
		name: 	'haymaker',
		text: 	'Get 25% more grass and hay each level.',
		background_item: 	'hay',
		cost: 			1,
		item_bonus:{
			grass: 		25,
			hay: 		25,
		},
		skill_bonus:{
		}
	},
	breeder: {
		name: 	'breeder',
		text: 	'Get 25% more chickens, roosters, sheep, cows and horses each level.',
		background_item: 	'rooster',
		cost: 			4,
		item_bonus:{
			chicken: 		25,
			rooster: 		25,
			sheep: 			25,
			cow: 			25,
			horse: 			25,
		},
		skill_bonus:{
		}
	},
	weaver: {
		name: 	'weaver',
		text: 	'Get 25% more cloth and leather each level.',
		background_item: 	'cloth',
		cost: 			3,
		item_bonus:{
			cloth: 			25,
			leather: 		25,
		},
		skill_bonus:{
		}
	},
	alchemist: {
		name: 	'alchemist',
		text: 	'Get 25% more items from alchemy each level.',
		background_item: 	'health_potion',
		cost: 			5,
		item_bonus:{
		},
		skill_bonus:{
			alchemy: 		25
		}
	},
	rocky: {
		name: 	'rocky',
		text: 	'Get 25% more stone each level.',
		background_item: 	'stone',
		cost: 			1,
		item_bonus:{
			stone: 		25,
		},
		skill_bonus:{
		}
	},
	miner: {
		name: 	'miner',
		text: 	'Get 25% more items from mining each level.',
		background_item: 	'miner',
		cost: 			5,
		item_bonus:{
		},
		skill_bonus:{
			mining: 	25
		}
	},
	fisharman: {
		name: 	'fisherman',
		text: 	'Get 25% more items from fishing each level.',
		background_item: 	'fisherman',
		cost: 			2,
		item_bonus:{
		},
		skill_bonus:{
			fishing: 	25
		}
	},
	farmer: {
		name: 	'farmer',
		text: 	'Get 25% more items from farming each level.',
		background_item: 	'farmer',
		cost: 			2,
		item_bonus:{
		},
		skill_bonus:{
			farming: 	25
		}
	},
	hunter: {
		name: 	'hunter',
		text: 	'Get 25% more items from hunting each level.',
		background_item: 	'hunter',
		cost: 			3,
		item_bonus:{
		},
		skill_bonus:{
			hunting: 	25
		}
	},
}

available_ap_bonusses = sortObj(available_ap_bonusses);