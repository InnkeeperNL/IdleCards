var available_units = {
	
}