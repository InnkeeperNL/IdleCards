var available_actions = {
	pick_parsley:{
		name: 			'Pick parsley',
		unlock_name: 	'Plant parsley',
		item_id: 		'parsley',
		chance: 		25,
		skill: 			'herbalism',
		action_name: 		'pick',
		fail_text: 		'pick',
		unlock_cost:{
			water:  	50,
		}
	},
	pick_mint:{
		name: 			'Pick mint',
		unlock_name: 	'Plant mint',
		item_id: 		'mint',
		chance: 		25,
		skill: 			'herbalism',
		action_name: 		'pick',
		fail_text: 		'pick',
		unlock_cost:{
			water:  	50,
		}
	},
	pick_sage:{
		name: 			'Pick sage',
		unlock_name: 	'Plant sage',
		item_id: 		'sage',
		chance: 		25,
		skill: 			'herbalism',
		action_name: 		'pick',
		fail_text: 		'pick',
		unlock_cost:{
			water:  	50,
		}
	},
	pick_rosemary:{
		name: 			'Pick rosemary',
		unlock_name: 	'Plant rosemary',
		item_id: 		'rosemary',
		chance: 		25,
		skill: 			'herbalism',
		action_name: 		'pick',
		fail_text: 		'pick',
		unlock_cost:{
			water:  	50,
		}
	},
	look_for_herbs:{
		name: 			'Pick herbs',
		unlock_name: 	'Look for herbs',
		item_id: 		'parsley',
		bonus_loot:{
			mint: 		50,
			sage: 		25,
			rosemary: 	12,
		},
		chance: 		25,
		skill: 			'herbalism',
		action_name: 		'pick',
		fail_text: 		'pick',
		unlock_cost:{
			grass:  	50,
		}
	},
	comb_the_beach:{
		name: 			'Comb the beach',
		bonus_loot:{
			sand: 		100,
			firewood: 	75,
			twine: 		10,
			plank: 		5
		},
		chance: 		25,
		skill: 			'gathering',
		action_name: 		'comb',
		fail_text: 		'comb',
	},
	scrounge_wrecks:{
		name: 			'Scrounge wrecks',
		unlock_name: 	'Build sandbanks',
		bonus_loot:{
			firewood: 	100,
			nails: 		35,
			peasant: 	20,
			plank: 		10,
			cloth: 		10,
			barrel: 	2,
			crate: 		2,
		},
		chance: 		25,
		skill: 			'gathering',
		action_name: 	'scrounge',
		fail_text: 		'scrounge',
		upgrade_item: 	'sand',
		unlock_cost:{
			sand:		100,
		}
	},
	build_ship:{
		name: 			'Build ship',
		unlock_name: 	'Build drydock',
		bonus_loot:{
			ship: 	100,
		},
		chance: 		25,
		skill: 			'carpentry',
		action_name: 	'build',
		fail_text: 		'build',
		cost:{
			plank:		10,
			nails: 		10,
			twine: 		10,
			cloth: 		5,
			peasant: 	5,
		},
		unlock_cost:{
			plank:		10,
			nails: 		10,
			twine: 		10,
		}
	},
	build_fishing_ship:{
		name: 			'Build fishing ship',
		unlock_name: 	'Build fishing docks',
		bonus_loot:{
			fishing_ship: 	100,
		},
		chance: 		25,
		skill: 			'carpentry',
		action_name: 	'build',
		fail_text: 		'build',
		cost:{
			ship:		1,
			fisherman: 	5,
		},
		unlock_cost:{
			plank:		10,
			nails: 		20,
			twine: 		10,
			fisherman: 	5,
		}
	},
	catch_seafish:{
		name: 			'Send out fishing ships',
		unlock_name: 	'Start sending out fishing ships',
		bonus_loot:{
			salmon: 		100,
			eel: 			50,
		},
		progress_needed: 1,
		reward_factor: 	10,
		chance: 		25,
		skill: 			'fishing',
		action_name: 	'fish',
		fail_text: 		'fail',
		upgrade_item: 	'fishing_ship',
		unlock_cost:{
			fishing_ship: 	1,
			barrel:  		5,
		}
	},
	ship_goods:{
		name: 			'Ship goods',
		unlock_name: 	'Set up goods shipping',
		bonus_loot:{
			treasure: 	100,
		},
		chance: 		25,
		skill: 			'trading',
		action_name: 	'ship',
		fail_text: 		'ship',
		upgrade_item: 	'ship',
		cost:{
			supplies:	6,
		},
		unlock_cost:{
			ship:		1,
			supplies: 	5,
		}
	},
	import_tools:{
		name: 			'Import tools',
		unlock_name: 	'Set up tool imports',
		bonus_loot:{
			axe: 		50,
			knife:		50,
			net: 		50,
			pickaxe: 	50,
			pitchfork: 	50,
			plow: 		50,
		},
		chance: 		25,
		skill: 			'trading',
		action_name: 	'import',
		fail_text: 		'import',
		upgrade_item: 	'ship',
		unlock_cost:{
			ship:		1,
		}
	},
	import_goods:{
		name: 			'Import goods',
		unlock_name: 	'Set up goods imports',
		bonus_loot:{
			lumber: 	50,
			stone: 		50,
			nails:		50,
			flour: 		25,
			iron: 		20,
			meat: 		15,
			cloth: 		10,
			supplies: 	5,
		},
		chance: 		25,
		skill: 			'trading',
		action_name: 	'import',
		fail_text: 		'import',
		upgrade_item: 	'ship',
		unlock_cost:{
			ship:		1,
		}
	},
	boil_water:{
		name: 			'Boil seawater',
		unlock_name: 	'Start boiling seawater',
		bonus_loot:{
			water: 		100,
			salt: 		10,
		},
		chance: 		25,
		reward_factor: 	10,
		passive_factor: 1,
		skill: 			'cooking',
		action_name: 	'boil',
		fail_text: 		'boil',
		upgrade_item: 	'firewood',
		cost:{
			firewood: 	10,
		},
		unlock_cost:{
			firewood:		100,
		}
	},
	comb_the_shore:{
		name: 			'Comb the shore',
		item_id: 		'water',
		bonus_loot:{
			firewood: 	75,
			twine: 		10,
			barrel: 	0.25
		},
		chance: 		25,
		skill: 			'gathering',
		action_name: 		'comb',
		fail_text: 		'comb',
	},
	save_swimmer:{
		name: 			'Save swimmer',
		unlock_name: 	'Build a small raft',
		item_id: 		'peasant',
		chance: 		20,
		skill: 			'swimming',
		action_name: 	'save',
		fail_text: 		'save',
		cost:{
			firewood: 		6
		},
		unlock_cost:{
			firewood:		25,
		}
	},
	craft_net:{
		name: 			'Craft net',
		unlock_name: 	'Learn some knots',
		item_id: 		'net',
		chance: 		20,
		skill: 			'tailoring',
		action_name: 	'craft',
		fail_text: 		'craft',
		cost:{
			twine: 		2
		},
		unlock_cost:{
			twine:		1,
		}
	},
	gather_water:{
		name: 			'Gather water',
		item_id: 		'water',
		chance: 		25,
		skill: 			'gathering',
		action_name: 		'gather',
		fail_text: 		'gather',
	},
	gather_sand:{
		name: 			'Gather sand',
		item_id: 		'sand',
		chance: 		25,
		skill: 			'gathering',
		action_name: 		'gather',
		fail_text: 		'gather',
		unlock_cost:{
			water:  	50,
		}
	},
	gather_clay:{
		name: 			'Dig for clay',
		unlock_name: 	'Look for clay',
		item_id: 		'clay',
		bonus_loot: {
			sand: 		25,
			stone: 		10
		},
		chance: 		25,
		skill: 			'mining',
		action_name: 		'dig',
		fail_text: 		'dig',
		unlock_cost:{
			water:  	50,
		}
	},
	catch_fish:{
		name: 			'Catch fish',
		unlock_name: 	'Practice fishing',
		bonus_loot:{
			perch: 			40,
			trout: 			20,
			salmon: 		10,
			eel: 			5,
		},
		progress_needed: 1,
		chance: 		25,
		skill: 			'fishing',
		action_name: 	'fish',
		fail_text: 		'fail',
		upgrade_item: 	'fisherman',
		unlock_cost:{
			net:  		1,
		}
	},
	roast_perch:{
		name: 			'Smoke perch',
		unlock_name: 	'Practice smoking perch',
		item_id: 		'smoked_fish',
		chance: 		25,
		skill: 			'cooking',
		action_name: 		'cook',
		fail_text: 		'cook',
		upgrade_item: 	'firewood',
		cost:{
			perch: 		5,
			firewood: 	5
		},
		unlock_cost:{
			perch:  		10,
			firewood: 		10
		}
	},
	grill_trout:{
		name: 			'Smoke trout',
		unlock_name: 	'Practice smoking trout',
		item_id: 		'smoked_fish',
		chance: 		25,
		skill: 			'cooking',
		action_name: 		'cook',
		fail_text: 		'cook',
		upgrade_item: 	'firewood',
		cost:{
			trout: 		3,
			firewood: 	5
		},
		unlock_cost:{
			trout:  		10,
			firewood: 		10
		}
	},
	
	cook_salmon:{
		name: 			'Smoke salmon',
		unlock_name: 	'Practice smoking salmon',
		item_id: 		'smoked_fish',
		chance: 		25,
		skill: 			'cooking',
		action_name: 		'cook',
		fail_text: 		'cook',
		upgrade_item: 	'firewood',
		cost:{
			salmon: 	1,
			firewood: 	3,
		},
		unlock_cost:{
			salmon:  		10,
			firewood: 		10,
		}
	},
	cook_eel:{
		name: 			'Smoke eel',
		unlock_name: 	'Practice smoking eel',
		item_id: 		'smoked_fish',
		chance: 		25,
		reward_factor: 	1,
		skill: 			'cooking',
		action_name: 		'cook',
		fail_text: 		'cook',
		upgrade_item: 	'firewood',
		cost:{
			eel: 		1,
			firewood: 	1,
		},
		unlock_cost:{
			eel:  			10,
			firewood: 		10,
		}
	},
	catch_perch:{
		name: 			'Catch perch',
		item_id: 		'perch',
		chance: 		25,
		skill: 			'fishing',
		action_name: 		'fish',
		fail_text: 		'fish',
		unlock_cost:{
			water:  	50,
		}
	},
	package_fish:{
		name: 			'Package fish',
		unlock_name: 	'Set up fish packaging',
		item_id: 		'supplies',
		chance: 		25,
		skill: 			'packaging',
		action_name: 		'pack',
		fail_text: 		'pack',
		cost:{
			smoked_fish: 	5,
			barrel: 		1,
		},
		unlock_cost:{
			smoked_fish:  	10,
			barrel: 		3,
		}
	},
	pick_apples:{
		name: 			'Pick apples',
		unlock_name: 	'plant some apple trees',
		item_id: 		'apple',
		chance: 		10,
		skill: 			'gathering',
		action_name: 	'pick',
		fail_text: 		'pick',
		upgrade_item: 	'water',
		unlock_cost:{
			apple: 		10,
			water: 		100,
		}
	},
	chop_wood:{
		name: 			'Harvest small tree',
		unlock_name: 	'Look for some small trees',
		item_id: 		'lumber',
		bonus_loot:{
			firewood: 	100,
			leaves: 	10,
			hardwood: 	0.01,
		},
		progress_needed: 	1,
		reward_factor: 		5,
		chance: 		5,
		skill: 			'woodcutting',
		action_name: 	'chop',
		fail_text: 		'chop',
	},
	chop_down_tree:{
		name: 			'Chop down tree',
		unlock_name: 	'Put lumberjacks to work',
		item_id: 		'lumber',
		bonus_loot:{
			firewood: 	100,
			leaves: 	10,
			hardwood: 	0.001,
		},
		progress_needed: 	1,
		reward_factor: 		100,
		passive_factor: 	10,
		chance: 		5,
		skill: 			'woodcutting',
		action_name: 		'chop',
		fail_text: 		'chop',
		upgrade_item: 		'lumberjack',
		unlock_cost:{
			lumberjack:		1
		}
	},
	chop_hardwood:{
		name: 			'Chop hardwood',
		unlock_name: 	'Search for hardwood trees',
		item_id: 		'hardwood',
		chance: 		5,
		skill: 			'woodcutting',
		action_name: 		'chop',
		fail_text: 		'chop',
		upgrade_item: 	'lumberjack',
		cost:{
			axe: 		3
		},
		unlock_cost:{
			lumberjack:		10
		}
	},
	search_for_firewood:{
		name: 			'Search for firewood',
		item_id: 		'firewood',
		chance: 		25,
		skill: 			'gathering',
		action_name: 	'search',
		fail_text: 		'search',
	},
	scrounge_the_forest:{
		name: 			'Search the forest',
		item_id: 		'firewood',
		bonus_loot:{
			water: 		15,
			apple: 		10,
			feather: 	8,
			twine: 		5,
			peasant: 	3,
			axe: 		0.5,
		},
		chance: 		25,
		skill: 			'gathering',
		action_name: 	'scrounge',
		fail_text: 		'scrounge',
	},
	chop_firewood:{
		name: 			'Chop firewood',
		unlock_name: 	'Start chopping firewood',
		item_id: 		'firewood',
		chance: 		25,
		reward_factor: 	8,
		skill: 			'woodcutting',
		action_name: 	'chop',
		fail_text: 		'chop',
		upgrade_item: 	'lumberjack',
		cost:{
			lumber: 	1
		},
		unlock_cost:{
			axe: 		1,
			lumber: 	10,
		}
	},
	mow_grass:{
		name: 			'Mow grass',
		item_id: 		'grass',
		chance: 		25,
		reward_factor: 	5,
		skill: 			'gathering',
		action_name: 	'mow',
		fail_text: 		'mow',
	},
	dry_grass:{
		name: 			'Dry grass',
		unlock_name: 	'Start drying grass',
		item_id: 		'hay',
		chance: 		25,
		reward_factor: 	1,
		skill: 			'gathering',
		action_name: 	'dry',
		fail_text: 		'dry',
		cost:{
			grass: 		3
		},
		unlock_cost:{
			grass: 		50
		}
	},
	bind_hay:{
		name: 			'Bind hay',
		unlock_name: 	'Start binding the hay',
		item_id: 		'hay_bale',
		chance: 		25,
		passive_factor: 1,
		skill: 			'gathering',
		action_name: 	'bind',
		fail_text: 		'bind',
		cost:{
			hay: 		3
		},
		unlock_cost:{
			hay: 		50
		}
	},
	craft_pole:{
		name: 			'Craft poles',
		unlock_name: 	'Learn to craft poles',
		item_id: 		'pole',
		chance: 		20,
		reward_factor: 	2,
		skill: 			'carpentry',
		action_name: 	'craft',
		fail_text: 		'craft',
		cost:{
			lumber: 	3
		},
		unlock_cost:{
			lumber:		20,
		}
	},
	saw_planks:{
		name: 			'Saw a plank',
		unlock_name: 	'Learn to saw planks',
		item_id: 		'plank',
		chance: 		20,
		skill: 			'carpentry',
		action_name: 		'saw',
		fail_text: 		'saw',
		cost:{
			lumber: 	3
		},
		unlock_cost:{
			lumber:		50,
		}
	},
	saw_planks_sawmill:{
		name: 			'Saw planks',
		unlock_name: 	'Build a sawmill',
		item_id: 		'plank',
		chance: 		20,
		reward_factor: 	10,
		skill: 			'carpentry',
		action_name: 	'saw',
		fail_text: 		'saw',
		cost:{
			lumber: 	10,
			iron: 		4
		},
		unlock_cost:{
			plank:		50,
			stone: 		50,
			iron: 		10
		}
	},
	craft_crate:{
		name: 			'Craft crate',
		unlock_name: 	'Learn to craft crates',
		item_id: 		'crate',
		chance: 		20,
		skill: 			'carpentry',
		action_name: 		'craft',
		fail_text: 		'craft',
		cost:{
			plank: 		2
		},
		unlock_cost:{
			plank:		30,
		}
	},
	craft_barrel:{
		name: 			'Craft barrel',
		unlock_name: 	'Learn to craft barrels',
		item_id: 		'barrel',
		chance: 		20,
		skill: 			'carpentry',
		action_name: 		'craft',
		fail_text: 		'craft',
		cost:{
			plank: 		2
		},
		unlock_cost:{
			plank:		30,
		}
	},
	
	craft_bed:{
		name: 			'Craft bed',
		unlock_name: 	'Learn to craft beds',
		item_id: 		'bed',
		chance: 		20,
		skill: 			'carpentry',
		action_name: 		'craft',
		fail_text: 		'craft',
		cost:{
			cloth: 		1,
			pillow: 	1,
			plank: 		4,
		},
		unlock_cost:{
			cloth: 		10,
			pillow: 	10,
			plank: 		40,
			
		}
	},
	craft_cart:{
		name: 			'Craft cart',
		unlock_name: 	'Learn to craft carts',
		item_id: 		'cart',
		chance: 		20,
		skill: 			'carpentry',
		action_name: 		'craft',
		fail_text: 		'craft',
		cost:{
			pole: 		6,
			plank: 		6,
			nails: 		15
		},
		unlock_cost:{
			pole: 		25,
			plank: 		25,
			nails: 		50
		}
	},
	send_supplies:{
		name: 			'Send supplies',
		unlock_name: 	'Set up a supply depot',
		item_id: 		'treasure',
		chance: 		20,
		passive_factor: 	5,
		skill: 			'trading',
		action_name: 		'send',
		fail_text: 		'send',
		upgrade_item: 		'cart',
		cost:{
			supplies: 	6,
		},
		unlock_cost:{
			plank: 		20,
			pole: 		20,
			nails: 		50,
			supplies: 	10,
			peasant: 	10,
		}
	},
	
	dig_hole:{
		name: 			'Dig a hole',
		item_id: 		'sand',
		bonus_loot:{
			firewood: 	25,
			stone: 		20,
			copper_ore: 	2.5,
			lumber: 	1,
		},
		chance: 		10,
		skill: 			'mining',
		action_name: 		'dig',
		fail_text: 		'dig',
		unlock_cost:{
			coins:		1,
		}
	},
	break_rocks:{
		name: 			'Break rocks',
		unlock_name: 	'Start breaking rocks',
		item_id: 		'stone',
		bonus_loot:{
			copper_ore: 	20,
			iron_ore: 	10,
		},
		chance: 		10,
		skill: 			'mining',
		action_name: 	'mine',
		fail_text: 		'mine',
		upgrade_item: 	'miner',
		unlock_cost:{
			pickaxe:		1,
		}
	},
	mine_stone:{
		name: 			'Mine stone',
		unlock_name: 	'Build a quarry',
		item_id: 		'stone',
		chance: 		10,
		skill: 			'mining',
		action_name: 		'mine',
		fail_text: 		'mine',
		upgrade_item: 	'miner',
		unlock_cost:{
			miner: 		10,
			stone:		250,
		}
	},
	mine_copper:{
		name: 			'Mine copper',
		unlock_name: 	'Build a copper mine',
		item_id: 		'copper_ore',
		chance: 		2.5,
		skill: 			'mining',
		action_name: 	'mine',
		fail_text: 		'mine',
		upgrade_item: 	'miner',
		unlock_cost:{
			miner: 		10,
			stone:		250,
		}
	},
	mine_coal:{
		name: 			'Mine coal',
		unlock_name: 	'Build a coal mine',
		item_id: 		'coal',
		chance: 		5,
		skill: 			'mining',
		action_name: 		'mine',
		fail_text: 		'mine',
		upgrade_item: 	'miner',
		unlock_cost:{
			miner: 		10,
			stone:		250,
		}
	},
	mine_salt:{
		name: 			'Mine salt',
		unlock_name: 	'Build a salt mine',
		item_id: 		'salt',
		chance: 		5,
		skill: 			'mining',
		action_name: 	'mine',
		fail_text: 		'mine',
		upgrade_item: 	'miner',
		unlock_cost:{
			miner: 		10,
			stone:		250,
		}
	},
	mine_iron:{
		name: 			'Mine iron',
		unlock_name: 	'Build an iron mine',
		item_id: 		'iron_ore',
		chance: 		5,
		skill: 			'mining',
		action_name: 	'mine',
		fail_text: 		'mine',
		upgrade_item: 	'miner',
		unlock_cost:{
			miner: 		10,
			stone:		250,
		}
	},
	mine_silver:{
		name: 			'Mine silver',
		unlock_name: 	'Build a silver mine',
		item_id: 		'silver_ore',
		chance: 		5,
		skill: 			'mining',
		action_name: 	'mine',
		fail_text: 		'mine',
		upgrade_item: 	'miner',
		unlock_cost:{
			miner: 		20,
			stone:		500,
		}
	},
	mine_gold:{
		name: 			'Mine gold',
		unlock_name: 	'Build a gold mine',
		item_id: 		'gold_ore',
		chance: 		5,
		skill: 			'mining',
		action_name: 	'mine',
		fail_text: 		'mine',
		upgrade_item: 	'miner',
		unlock_cost:{
			miner: 		40,
			stone:		1000,
		}
	},
	tend_vegetable_garden:{
		name: 			'Tend the vegetables',
		item_id: 		'lettuce',
		bonus_loot:{
			cucumber: 	50,
			tomato: 	50,
			onion: 		25,
			potato: 	25,
			carrot: 	10
		},
		chance: 		5,
		reward_factor: 	1,
		skill: 			'farming',
		action_name: 		'farm',
		fail_text: 		'farm',
		unlock_cost:{
			farmer:		1,
		}
	},
	grow_lettuce:{
		name: 			'Grow lettuce',
		unlock_name: 	'Plant lettuce',
		item_id: 		'lettuce',
		chance: 		5,
		reward_factor: 	5,
		skill: 			'farming',
		action_name: 		'farm',
		fail_text: 		'farm',
		unlock_cost:{
			water:		100,
		}
	},
	grow_cucumber:{
		name: 			'Grow cucumbers',
		unlock_name: 	'Plant cucumbers',
		item_id: 		'cucumber',
		chance: 		5,
		reward_factor: 	5,
		skill: 			'farming',
		action_name: 		'farm',
		fail_text: 		'farm',
		unlock_cost:{
			water:		100,
		}
	},
	grow_tomatoes:{
		name: 			'Grow tomatoes',
		unlock_name: 	'Plant tomatoes',
		item_id: 		'tomato',
		chance: 		5,
		reward_factor: 	5,
		skill: 			'farming',
		action_name: 		'farm',
		fail_text: 		'farm',
		unlock_cost:{
			water:		100,
		}
	},

	grow_carrots:{
		name: 			'Grow carrots',
		unlock_name: 	'Plant carrots',
		item_id: 		'carrot',
		chance: 		5,
		skill: 			'farming',
		action_name: 		'farm',
		fail_text: 		'farm',
		unlock_cost:{
			water:		100,
		}
	},
	grow_onions:{
		name: 			'Grow onions',
		unlock_name: 	'Plant onions',
		item_id: 		'onion',
		chance: 		2.5,
		reward_factor: 	5,
		skill: 			'farming',
		action_name: 		'farm',
		fail_text: 		'farm',
		unlock_cost:{
			water:		100,
		}
	},
	grow_potatoes:{
		name: 			'Grow potatoes',
		unlock_name: 	'Plant potatoes',
		item_id: 		'potato',
		chance: 		2.5,
		reward_factor: 	5,
		skill: 			'farming',
		action_name: 		'farm',
		fail_text: 		'farm',
		unlock_cost:{
			water:		100,
		}
	},
	grow_wheat:{
		name: 			'Tend wheat',
		unlock_name: 	'Plow a wheat field',
		item_id: 		'wheat',
		chance: 		5,
		reward_factor: 		50,
		skill: 			'farming',
		action_name: 		'farm',
		fail_text: 		'farm',
		upgrade_item: 		'farmer',
		cost:{
			plow: 		1
		},
		unlock_cost:{
			plow: 		1
		}
	},
	grow_flax:{
		name: 			'Tend flax',
		unlock_name: 	'Plow a flax field',
		item_id: 		'flax',
		chance: 		5,
		reward_factor: 		50,
		skill: 			'farming',
		action_name: 		'farm',
		fail_text: 		'farm',
		upgrade_item: 		'farmer',
		cost:{
			plow: 		1
		},
		unlock_cost:{
			plow: 		1
		}
	},
	grow_sugarcane:{
		name: 			'Tend sugarcane',
		unlock_name: 	'Plow a sugarcane field',
		item_id: 		'sugarcane',
		chance: 		5,
		reward_factor: 		15,
		skill: 			'farming',
		action_name: 		'farm',
		fail_text: 		'farm',
		upgrade_item: 		'farmer',
		cost:{
			plow: 		1
		},
		unlock_cost:{
			plow: 		1
		}
	},
	clear_the_field:{
		name: 			'Clear the field',
		item_id: 		'stone',
		bonus_loot:{
			firewood: 	10,
			grass: 		5,
			wheat: 		1,
		},
		progress_needed: 	1,
		reward_factor: 		5,
		chance: 		5,
		skill: 			'gathering',
		action_name: 	'clear',
		fail_text: 		'clear',
	},
	use_the_well:{
		name: 			'Use the well',
		unlock_name: 	'Build a well',
		item_id: 		'water',
		bonus_loot:{
			sand: 		5,
			stone: 		1,
			boots: 		0.1,
		},
		chance: 		5,
		reward_factor: 		10,
		skill: 			'gathering',
		action_name: 	'collect',
		fail_text: 		'collect',
		upgrade_item: 	'stone',
		unlock_cost:{
			stone: 		25
		}
	},
	assist_the_farmers:{
		name: 			'Assist the farmers',
		unlock_name: 	'Make friends',
		item_id: 		'wheat',
		bonus_loot:{
			peasant: 	10,
			pitchfork: 	10,
			sack: 		4,
			plow: 		2,
			knife: 		0.3,
		},
		chance: 		5,
		skill: 			'charm',
		action_name: 	'assist',
		fail_text: 		'assist',
		cost:{
			water: 		10
		},
		unlock_cost:{
			water: 		50
		}
	},
	train_guard:{
		name: 			'Train guard',
		unlock_name: 	'Set up guard training',
		item_id: 		'guard',
		chance: 		5,
		skill: 			'training',
		action_name: 	'train',
		fail_text: 		'train',
		cost:{
			peasant: 		1,
			spear: 			2,
			plate_armor: 	1,
			shield: 		1
		},
		unlock_cost:{
			house: 			1,
			peasant: 		10,
			spear: 			10,
			plate_armor: 	10,
			shield: 		10
		}
	},
	train_farmer:{
		name: 			'Train farmer',
		unlock_name: 	'Set up farmer training',
		item_id: 		'farmer',
		chance: 		5,
		skill: 			'training',
		action_name: 	'train',
		fail_text: 		'train',
		cost:{
			peasant: 		1,
			pitchfork: 		1
		},
		unlock_cost:{
			coins: 		1000
		}
	},
	train_fisherman:{
		name: 			'Train fisherman',
		unlock_name: 	'Learn to train fishermen',
		item_id: 		'fisherman',
		chance: 		5,
		skill: 			'training',
		action_name: 	'train',
		fail_text: 		'train',
		cost:{
			peasant: 		1,
			net: 			1
		},
		unlock_cost:{
			coins: 		1000
		}
	},
	train_hunter:{
		name: 			'Train hunter',
		unlock_name: 	'Set up hunter training',
		item_id: 		'hunter',
		chance: 		5,
		skill: 			'training',
		action_name: 	'train',
		fail_text: 		'train',
		cost:{
			peasant: 		1,
			bow: 			1
		},
		unlock_cost:{
			coins: 		1000
		}
	},
	train_veteran_hunter:{
		name: 			'Train veteran hunter',
		unlock_name: 	'Set up veteran training',
		item_id: 		'veteran_hunter',
		chance: 		5,
		skill: 			'training',
		action_name: 	'train',
		fail_text: 		'train',
		cost:{
			hunter: 		1,
			spear: 			10
		},
		unlock_cost:{
			hunter: 	10,
			spear: 		100
		}
	},
	
	train_miner:{
		name: 			'Train miner',
		unlock_name: 	'Set up miner training',
		item_id: 		'miner',
		chance: 		5,
		skill: 			'training',
		action_name: 	'train',
		fail_text: 		'train',
		cost:{
			peasant: 		1,
			pickaxe: 		1
		},
		unlock_cost:{
			coins: 		1000
		}
	},
	train_lumberjack:{
		name: 			'Train lumberjack',
		unlock_name: 	'Set up lumberjack training',
		item_id: 		'lumberjack',
		chance: 		5,
		skill: 			'training',
		action_name: 	'train',
		fail_text: 		'train',
		cost:{
			peasant: 		1,
			axe: 			1
		},
		unlock_cost:{
			coins: 		1000
		}
	},

	tend_the_field:{
		name: 			'Tend the field',
		unlock_name: 	'Grow crops',
		item_id: 		'wheat',
		bonus_loot:{
			flax: 			50,
			sugarcane: 		5,
		},
		chance: 		5,
		reward_factor: 		10,
		skill: 			'farming',
		action_name: 	'farm',
		fail_text: 		'farm',
		upgrade_item: 	'farmer',
		unlock_cost:{
			water: 		100
		}
	},
	tend_large_field:{
		name: 			'Tend a large field',
		unlock_name: 	'Plow a large field',
		item_id: 		'wheat',
		bonus_loot:{
			flax: 			50,
			sugarcane: 		5,
		},
		chance: 		5,
		reward_factor: 		35,
		skill: 			'farming',
		action_name: 	'farm',
		fail_text: 		'farm',
		upgrade_item: 	'farmer',
		cost:{
			plow: 		1
		},
		unlock_cost:{
			plow: 		1
		}
	},
	package_flour:{
		name: 			'Package flour',
		unlock_name: 	'Set up flour packaging',
		item_id: 		'supplies',
		chance: 		25,
		skill: 			'packaging',
		action_name: 		'pack',
		fail_text: 		'pack',
		cost:{
			flour: 			20,
			sack: 			1,
		},
		unlock_cost:{
			flour:  		50,
			sack: 			2,
		}
	},
	mill_flour:{
		name: 			'Mill flour',
		unlock_name: 	'Build a wheat mill',
		item_id: 		'flour',
		chance: 		20,
		skill: 			'milling',
		action_name: 		'mill',
		fail_text: 		'mill',
		cost:{
			wheat: 	4
		},
		unlock_cost:{
			stone:		100,
		}
	},
	refine_sugar:{
		name: 			'Refine sugar',
		unlock_name: 	'Build a sugar mill',
		item_id: 		'sugar',
		chance: 		20,
		reward_factor: 	2,
		skill: 			'milling',
		action_name: 		'mill',
		fail_text: 		'mill',
		cost:{
			sugarcane: 	3
		},
		unlock_cost:{
			stone:		100,
		}
	},
	feed_chickens:{
		name: 			'Feed the chickens',
		unlock_name: 	'Lure some chickens',
		item_id: 		'egg',
		bonus_loot:{
			feather: 	10,
		},
		chance: 		20,
		reward_factor: 	6,
		skill: 			'husbandry',
		action_name: 		'feed',
		fail_text: 		'feed',
		cost:{
			wheat: 	4
		},
		unlock_cost:{
			wheat: 		100,
		}
	},
	breed_chickens:{
		name: 			'Hatch eggs',
		unlock_name: 	'Learn to breed chickens',
		item_id: 		'chicken',
		bonus_loot:{
			feather: 	50,
		},
		chance: 		20,
		skill: 			'husbandry',
		action_name: 	'breed',
		fail_text: 		'breed',
		cost:{
			egg: 	8
		},
		unlock_cost:{
			egg: 		100,
		}
	},
	transmute_stone:{
		name: 			'transmute stone',
		unlock_name: 	'Learn to transmute',
		item_id: 		'iron',
		chance: 		20,
		skill: 			'alchemy',
		action_name: 		'transmute',
		fail_text: 		'transmute',
		cost:{
			mint: 		3,
			stone: 		1,
		},
		unlock_cost:{
			mint: 		100,
			stone: 		100,
		}
	},
	transmute_iron:{
		name: 			'transmute iron',
		unlock_name: 	'Study transmutation',
		item_id: 		'gold',
		chance: 		20,
		skill: 			'alchemy',
		action_name: 		'transmute',
		fail_text: 		'transmute',
		cost:{
			mint: 		20,
			iron: 		2,
		},
		unlock_cost:{
			mint: 		100,
			iron: 		100,
		}
	},
	brew_health_potion:{
		name: 			'brew health potion',
		unlock_name: 	'Learn to brew health potions',
		item_id: 		'health_potion',
		chance: 		20,
		skill: 			'alchemy',
		action_name: 		'brew',
		fail_text: 		'brew',
		cost:{
			parsley: 	5,
			water: 		5,
			glass: 		1,
		},
		unlock_cost:{
			parsley: 	100,
			water: 		100,
			glass: 		10,
		}
	},
	craft_remedy:{
		name: 			'craft remedy',
		unlock_name: 	'Learn to craft remedies',
		item_id: 		'remedy',
		chance: 		20,
		skill: 			'alchemy',
		action_name: 		'craft',
		fail_text: 		'craft',
		cost:{
			parsley: 	10,
			mint: 		25,
		},
		unlock_cost:{
			parsley: 	100,
			mint: 		100,
		}
	},
	craft_first_aid_kit:{
		name: 			'craft first aid kit',
		unlock_name: 	'Learn to craft first aid kits',
		item_id: 		'first_aid_kit',
		chance: 		20,
		skill: 			'alchemy',
		action_name: 	'craft',
		fail_text: 		'craft',
		cost:{
			bandage: 		5,
			remedy: 		5,
			health_potion: 	6,
			crate: 			1
		},
		unlock_cost:{
			parsley: 	100,
			mint: 		100,
		}
	},
	brew_mana_potion:{
		name: 			'brew mana potion',
		unlock_name: 	'Learn to brew mana potions',
		item_id: 		'mana_potion',
		chance: 		20,
		skill: 			'alchemy',
		action_name: 		'brew',
		fail_text: 		'brew',
		cost:{
			sage: 		6,
			water: 		5,
			glass: 		1,
		},
		unlock_cost:{
			sage: 	100,
			water: 		100,
			glass: 		10,
		}
	},
	brew_poison:{
		name: 			'brew poison',
		unlock_name: 	'Learn to brew poison',
		item_id: 		'poison',
		chance: 		20,
		skill: 			'alchemy',
		action_name: 		'brew',
		fail_text: 		'brew',
		cost:{
			parsley: 	5,
			mint: 		5,
			bone: 		5,
			water: 		5,
			glass: 		1,
		},
		unlock_cost:{
			bone: 		150,
			water: 		100,
			glass: 		10,
		}
	},
	brew_love_potion:{
		name: 			'brew love potion',
		unlock_name: 	'Learn to brew love potions',
		item_id: 		'love_potion',
		chance: 		20,
		skill: 			'alchemy',
		action_name: 		'brew',
		fail_text: 		'brew',
		cost:{
			rosemary: 	6,
			water: 		5,
			glass: 		1,
		},
		unlock_cost:{
			rosemary: 	100,
			water: 		100,
			glass: 		10,
		}
	},
	brew_restore_potion:{
		name: 			'brew restore potion',
		unlock_name: 	'Learn to brew restore potions',
		item_id: 		'restore_potion',
		chance: 		20,
		skill: 			'alchemy',
		action_name: 		'brew',
		fail_text: 		'brew',
		cost:{
			health_potion: 	2,
			mana_potion: 	2,
			glass: 		1,
		},
		unlock_cost:{
			health_potion: 	20,
			mana_potion: 	20,
			glass: 		10,
		}
	},
	
	make_salad:{
		name: 			'Make salad',
		unlock_name: 	'Learn to make salads',
		item_id: 		'salad',
		chance: 		20,
		skill: 			'cooking',
		action_name: 		'make',
		fail_text: 		'make',
		cost:{
			lettuce: 	3,
			cucumber: 	1,
			tomato: 	1,
		},
		unlock_cost:{
			lettuce: 	30,
			cucumber: 	10,
			tomato: 	10,
		}
	},
	bake_bread:{
		name: 			'Bake bread',
		unlock_name: 	'Build an oven for bread',
		item_id: 		'bread',
		chance: 		20,
		skill: 			'cooking',
		action_name: 		'bake',
		fail_text: 		'bake',
		cost:{
			flour: 		1,
			water: 		1,
			firewood: 	5,
		},
		unlock_cost:{
			stone: 		250,
		}
	},
	make_cucumber_sandwich:{
		name: 			'Make cucumber sandwich',
		unlock_name: 	'Practice making cucumber sandwiches',
		item_id: 		'cucumber_sandwich',
		chance: 		20,
		skill: 			'cooking',
		action_name: 		'make',
		fail_text: 		'make',
		cost:{
			bread: 		1,
			butter: 	1,
			cucumber: 	2,
		},
		unlock_cost:{
			bread: 		5,
			butter: 	5,
			cucumber: 	10,
		}
	},
	cook_perch_and_potatoes:{
		name: 			'Perch and potatoes',
		unlock_name: 	'Learn to cook perch and potatoes',
		item_id: 		'perch_and_potatoes',
		chance: 		20,
		skill: 			'cooking',
		action_name: 		'bake',
		fail_text: 		'bake',
		cost:{
			perch: 		10,
			potato: 	1,
			firewood: 	5,
		},
		unlock_cost:{
			perch: 		50,
			potato: 	10,
			salt: 		10,
			parsley: 	10,
			firewood: 	50,
		}
	},
	brew_mint_tea:{
		name: 			'Brew mint tea',
		unlock_name: 	'Learn to brew mint tea',
		item_id: 		'mint_tea',
		chance: 		20,
		skill: 			'cooking',
		action_name: 		'make',
		fail_text: 		'make',
		cost:{
			mint: 		3,
			water: 		5,
			glass: 		1,
			firewood: 	2,
		},
		unlock_cost:{
			mint: 		50,
			water: 		100,
			glass: 		10,
			firewood: 	50,
		}
	},
	bake_fries:{
		name: 			'Bake fries',
		unlock_name: 	'Learn to bake fries',
		item_id: 		'fries',
		chance: 		20,
		skill: 			'cooking',
		action_name: 		'bake',
		fail_text: 		'bake',
		cost:{
			potato:		2,
			salt: 		1,
			firewood: 	5
		},
		unlock_cost:{
			potato:		10,
			salt: 		10,
			firewood: 	50
		}
	},
	bake_apple_pie:{
		name: 			'Bake apple pie',
		unlock_name: 	'Learn to bake apple pies',
		item_id: 		'apple_pie',
		chance: 		20,
		skill: 			'cooking',
		action_name: 		'bake',
		fail_text: 		'bake',
		cost:{
			egg:		3,
			flour: 		10,
			apple: 		10,
			sugar: 		2,
			firewood: 	5
		},
		unlock_cost:{
			egg:		10,
			flour: 		20,
			apple: 		50,
			sugar: 		10,
			firewood: 	50
		}
	},
	build_wall:{
		name: 			'Build wall',
		unlock_name: 	'Practice masonry',
		item_id: 		'wall',
		chance: 		20,
		skill: 			'construction',
		action_name: 	'build',
		fail_text: 		'build',
		cost:{
			brick: 		8,
		},
		unlock_cost:{
			brick: 		25,
		}
	},
	build_house:{
		name: 			'Build house',
		unlock_name: 	'Start construction',
		item_id: 		'house',
		chance: 		20,
		skill: 			'construction',
		action_name: 	'build',
		fail_text: 		'build',
		cost:{
			glass: 		2,
			plank: 		4,
			shingle: 	4,
			wall: 		3,
		},
		unlock_cost:{
			glass: 		10,
			plank: 		20,
			shingle: 	20,
			wall: 		10,
		}
	},
	attract_peasant:{
		name: 			'Attract new villagers',
		unlock_name: 	'Expand the village',
		bonus_loot:{
			fisherman: 	60,
			hunter: 	50,
			farmer: 	50,
			lumberjack: 50,
			miner: 		50,
			thief: 		20,
			guard: 		20,
			cowboy: 	20,
		},
		chance: 		20,
		skill: 			'charm',
		action_name: 	'attract',
		fail_text: 		'attract',
		upgrade_item: 	'house',
		unlock_cost:{
			house: 			5,
		}
	},
	train_thief:{
		name: 			'Train thief',
		unlock_name: 	'Set up a thieves guild',
		item_id: 		'thief',
		chance: 		20,
		skill: 			'conscription',
		action_name: 	'train',
		fail_text: 		'train',
		cost:{
			cloak: 				1,
			peasant: 			1,
			sinister_dagger: 	1,
		},
		unlock_cost:{
			house: 				1,
			cloak: 				10,
			peasant: 			10,
			sinister_dagger: 	10,
		}
	},
	patrol_village:{
		name: 			'Patrol the village',
		unlock_name: 	'Start patrols',
		bonus_loot:{
			thief: 			20,
		},
		chance: 		25,
		skill: 			'stealing',
		action_name: 	'steal',
		fail_text: 		'failed',
		upgrade_item: 	'guard',
		unlock_cost:{
			guard:  		1,
		}
	},
	employ_thieves:{
		name: 			'Employ thieves',
		unlock_name: 	'Send out a thief',
		bonus_loot:{
			silver_ring: 		20,
			gold_ring: 			10,
			supplies: 			5,
			treasure: 			1,
		},
		chance: 		25,
		skill: 			'stealing',
		action_name: 	'steal',
		fail_text: 		'failed',
		upgrade_item: 	'thief',
		unlock_cost:{
			thief:  		1,
		}
	},
	train_cowboy:{
		name: 			'Train cowboy',
		unlock_name: 	'Learn to train cowboys',
		item_id: 		'cowboy',
		chance: 		20,
		skill: 			'conscription',
		action_name: 	'train',
		fail_text: 		'train',
		cost:{
			boots: 				1,
			horse: 				1,
			peasant: 			1,
			saddle: 			1,
		},
		unlock_cost:{
			boots: 				10,
			horse: 				10,
			peasant: 			10,
			saddle: 			10,
		}
	},
	sell_herd:{
		name: 			'Sell herd',
		unlock_name: 	'Employ cowboys',
		item_id: 		'treasure',
		chance: 		20,
		skill: 			'trading',
		action_name: 	'trade',
		fail_text: 		'trade',
		upgrade_item: 		'cowboy',
		cost:{
			cow: 				40,
		},
		unlock_cost:{
			cowboy: 			2,
		}
	},
	chisel_brick:{
		name: 			'Chisel brick',
		unlock_name: 	'Practice chisseling bricks',
		item_id: 		'brick',
		chance: 		20,
		skill: 			'construction',
		action_name: 	'chisel',
		fail_text: 		'chisel',
		cost:{
			stone: 		7,
		},
		unlock_cost:{
			stone: 		100,
		},
	},
	build_tollbridge:{
		name: 			'Collect toll',
		unlock_name: 	'Build a tollbridge',
		bonus_loot:{
			apple: 			30,
			bread: 			15,
			twine: 			15,
			barrel: 		6,
			net: 			2,
			cloth: 			2,
			nails: 			2,
			supplies: 		0.1,
		},
		chance: 		20,
		skill: 			'charm',
		action_name: 	'collect',
		fail_text: 		'collect',
		cost:{
			peasant: 	1,
		},
		unlock_cost:{
			brick: 		100,
		},
	},
	bake_brick:{
		name: 			'Bake brick',
		unlock_name: 	'Build brick oven',
		item_id: 		'brick',
		chance: 		20,
		skill: 			'pottery',
		action_name: 	'bake',
		fail_text: 		'bake',
		cost:{
			clay: 		3,
			firewood:	3,
		},
		unlock_cost:{
			stone: 		50,
		},
	},
	bake_shingle:{
		name: 			'Bake shingle',
		unlock_name: 	'Build shingle oven',
		item_id: 		'shingle',
		chance: 		20,
		skill: 			'pottery',
		action_name: 	'bake',
		fail_text: 		'bake',
		cost:{
			clay: 		3,
			firewood:	3,
		},
		unlock_cost:{
			stone: 		50,
		},
	},
	craft_charcoal:{
		name: 			'Fuel the bonfire',
		unlock_name: 		'Build a bonfire',
		item_id: 		'coal',
		bonus_loot:{
			peasant: 		10,
		},
		chance: 		20,
		reward_factor: 		2,
		skill: 			'burning',
		action_name: 		'burn',
		fail_text: 		'burn',
		cost:{
			firewood:	10,
		},
		unlock_cost:{
			firewood: 	10,
		},
	},
	smelt_copper:{
		name: 			'Smelt copper',
		unlock_name: 		'Build a small furnace',
		item_id: 		'copper',
		chance: 		20,
		reward_factor: 	1,
		skill: 			'smelting',
		action_name: 		'smelt',
		fail_text: 		'smelt',
		cost:{
			copper_ore:	1,
			firewood: 	2
		},
		unlock_cost:{
			stone:		10,
		},
	},
	smelt_silver:{
		name: 			'Smelt silver',
		unlock_name: 		'Build a silver furnace',
		item_id: 		'silver',
		chance: 		20,
		reward_factor: 	1,
		skill: 			'smelting',
		action_name: 		'smelt',
		fail_text: 		'smelt',
		cost:{
			silver_ore:	1,
			coal: 		5
		},
		unlock_cost:{
			stone:		250,
		},
	},
	smelt_gold:{
		name: 			'Smelt gold',
		unlock_name: 		'Build a golden furnace',
		item_id: 		'gold',
		chance: 		20,
		reward_factor: 	1,
		skill: 			'smelting',
		action_name: 		'smelt',
		fail_text: 		'smelt',
		cost:{
			gold_ore:	1,
			coal: 		10
		},
		unlock_cost:{
			stone:		1000,
		},
	},
	smelt_glass:{
		name: 			'Blow glass',
		unlock_name: 		'Learn to blow glass',
		item_id: 		'glass',
		chance: 		20,
		reward_factor: 	1,
		skill: 			'smelting',
		action_name: 		'smelt',
		fail_text: 		'smelt',
		cost:{
			sand:		8,
			firewood: 	2
		},
		unlock_cost:{
			sand:		80,
			firewood: 	20,
		},
	},
	smelt_iron:{
		name: 			'Smelt iron',
		unlock_name: 		'Build a large furnace',
		item_id: 		'iron',
		chance: 		20,
		reward_factor: 	1,
		skill: 			'smelting',
		action_name: 		'smelt',
		fail_text: 		'smelt',
		cost:{
			iron_ore:	1,
			coal: 		1
		},
		unlock_cost:{
			stone:		100,
		},
	},
	craft_copper_pot:{
		name: 			'Craft copper pot',
		unlock_name: 	'Learn to craft copper pots',
		item_id: 		'copper_pot',
		chance: 		20,
		skill: 			'smithing',
		action_name: 		'smith',
		fail_text: 		'smith',
		cost:{
			copper:		2,
		},
		unlock_cost:{
			copper:		20,
			coal: 		20
		}
	},
	craft_knife:{
		name: 			'Craft knife',
		unlock_name: 	'Learn to craft knives',
		item_id: 		'knife',
		chance: 		20,
		skill: 			'smithing',
		action_name: 		'smith',
		fail_text: 		'smith',
		cost:{
			iron:		1,
			lumber: 	1,
		},
		unlock_cost:{
			iron:		10,
			lumber: 	10
		}
	},
	craft_sinister_dagger:{
		name: 			'Craft sinister dagger',
		unlock_name: 	'Learn to craft sinister daggers',
		item_id: 		'sinister_dagger',
		chance: 		20,
		skill: 			'smithing',
		action_name: 		'smith',
		fail_text: 		'smith',
		cost:{
			knife:		1,
			poison: 	2
		},
		unlock_cost:{
			knife:		10,
			poison: 	10
		}
	},
	
	craft_arrow:{
		name: 			'Craft arrow',
		unlock_name: 	'Start fletching arrows',
		item_id: 		'arrow',
		chance: 		20,
		skill: 			'fletching',
		action_name: 		'craft',
		fail_text: 		'craft',
		cost:{
			feather:		1,
			firewood: 		1
		},
		unlock_cost:{
			feather:		1,
			firewood: 		5
		}
	},
	craft_bone_arrow:{
		name: 			'Craft bone arrow',
		unlock_name: 	'Start fletching  bone arrows',
		item_id: 		'arrow',
		chance: 		20,
		reward_factor: 	6,
		skill: 			'fletching',
		action_name: 		'craft',
		fail_text: 		'craft',
		cost:{
			feather:		1,
			firewood: 		1,
			bone: 			1
		},
		unlock_cost:{
			bone: 			10
		}
	},
	craft_bow:{
		name: 			'Craft bow',
		unlock_name: 	'Learn to craft bows',
		item_id: 		'bow',
		chance: 		20,
		skill: 			'fletching',
		action_name: 	'craft',
		fail_text: 		'craft',
		cost:{
			arrow:			5,
			lumber: 		1,
			twine: 			1
		},
		unlock_cost:{
			lumber: 		3,
			twine: 			3
		}
	},
	
	craft_silver_ring:{
		name: 			'Craft silver ring',
		unlock_name: 	'Practice forging silver rings',
		item_id: 		'silver_ring',
		chance: 		20,
		skill: 			'smithing',
		action_name: 		'smith',
		fail_text: 		'smith',
		cost:{
			silver:		1,
			coal: 		2
		},
		unlock_cost:{
			silver:		5,
			coal: 		200
		}
	},
	craft_gold_ring:{
		name: 			'Craft gold ring',
		unlock_name: 	'Practice forging gold rings',
		item_id: 		'gold_ring',
		chance: 		20,
		skill: 			'smithing',
		action_name: 		'smith',
		fail_text: 		'smith',
		cost:{
			gold:		1,
			coal: 		5
		},
		unlock_cost:{
			gold:		5,
			coal: 		400
		}
	},
	
	craft_nails:{
		name: 			'Craft nails',
		unlock_name: 	'Learn to make nails',
		item_id: 		'nails',
		chance: 		20,
		reward_factor: 	15,
		skill: 			'smithing',
		action_name: 		'smith',
		fail_text: 		'smith',
		cost:{
			iron:		1,
		},
		unlock_cost:{
			iron:		3,
		}
	},
	
	craft_shield:{
		name: 			'Craft shield',
		unlock_name: 	'Learn to craft shields',
		item_id: 		'shield',
		chance: 		20,
		reward_factor: 	1,
		skill: 			'carpentry',
		action_name: 		'craft',
		fail_text: 		'craft',
		cost:{
			iron:		1,
			plank: 		2
		},
		unlock_cost:{
			iron:		2,
			plank: 		4
		}
	},
	craft_plate_armor:{
		name: 			'Carft plate armor',
		unlock_name: 	'Learn to craft armor',
		item_id: 		'plate_armor',
		chance: 		20,
		reward_factor: 	1,
		skill: 			'smithing',
		action_name: 		'smith',
		fail_text: 		'smith',
		cost:{
			iron:		2,
			leather: 	2
		},
		unlock_cost:{
			iron:		3,
			leather: 	1
		}
	},
	
	craft_plow:{
		name: 			'Craft plow',
		unlock_name: 	'Learn to craft plows',
		item_id: 		'plow',
		chance: 		20,
		skill: 			'smithing',
		action_name: 		'smith',
		fail_text: 		'smith',
		cost:{
			iron:		1,
			plank: 		1,
			nails: 		5
		},
		unlock_cost:{
			iron:		5,
			plank: 		5,
			nails: 		25
		}
	},
	craft_axe:{
		name: 			'Craft axe',
		unlock_name: 	'Learn to craft axes',
		item_id: 		'axe',
		chance: 		20,
		skill: 			'smithing',
		action_name: 		'smith',
		fail_text: 		'smith',
		cost:{
			iron:		1,
			pole: 		1
		},
		unlock_cost:{
			iron:		2,
			pole: 		2
		}
	},
	craft_pitchfork:{
		name: 			'Craft pitchfork',
		unlock_name: 	'Learn to craft pitchforks',
		item_id: 		'pitchfork',
		chance: 		20,
		skill: 			'smithing',
		action_name: 		'smith',
		fail_text: 		'smith',
		cost:{
			iron:		1,
			pole: 		1
		},
		unlock_cost:{
			iron:		2,
			pole: 		2
		}
	},
	craft_pickaxe:{
		name: 			'Craft pickaxe',
		unlock_name: 	'Learn to craft pickaxes',
		item_id: 		'pickaxe',
		chance: 		20,
		skill: 			'smithing',
		action_name: 		'smith',
		fail_text: 		'smith',
		cost:{
			copper:		2,
			lumber: 	1
		},
		unlock_cost:{
			copper:		2,
			lumber: 	1
		}
	},
	craft_iron_pickaxe:{
		name: 			'Craft pickaxe',
		unlock_name: 	'Learn to craft iron pickaxes',
		item_id: 		'pickaxe',
		chance: 		20,
		skill: 			'smithing',
		action_name: 		'smith',
		fail_text: 		'smith',
		cost:{
			iron:		1,
			pole: 		1
		},
		unlock_cost:{
			iron:		2,
			pole: 		1
		}
	},
	craft_spear:{
		name: 			'Craft spear',
		unlock_name: 	'Learn to craft spears',
		item_id: 		'spear',
		chance: 		20,
		skill: 			'smithing',
		action_name: 		'smith',
		fail_text: 		'smith',
		cost:{
			iron:		1,
			pole: 		1
		},
		unlock_cost:{
			iron:		2,
			pole: 		2
		}
	},
	craft_bone_spear:{
		name: 			'Craft bone spear',
		unlock_name: 	'Learn to craft bone spears',
		item_id: 		'spear',
		chance: 		20,
		skill: 			'hunting',
		action_name: 		'craft',
		fail_text: 		'craft',
		cost:{
			bone:		4,
			lumber: 	2
		},
		unlock_cost:{
			bone:		30,
			lumber: 	20
		}
	},
	
	milk_cows:{
		name: 			'Milk cows',
		unlock_name: 	'Start milking cows',
		item_id: 		'milk',
		chance: 		20,
		skill: 			'husbandry',
		action_name: 		'milk',
		fail_text: 		'milk',
		upgrade_item: 		'cow',
		unlock_cost:{
			cow:		5,
		}
	},
	churn_butter:{
		name: 			'Churn butter',
		unlock_name: 		'Start churning butter',
		item_id: 		'butter',
		chance: 		20,
		skill: 			'cooking',
		action_name: 		'churn',
		fail_text: 		'churn',
		cost:{
			milk: 		3,
		},
		unlock_cost:{
			lumber:		5,
			milk: 		25,
		}
	},
	make_cheese:{
		name: 			'Make cheese',
		unlock_name: 		'Build cheesery',
		item_id: 		'cheese',
		chance: 		20,
		skill: 			'cooking',
		action_name: 		'make',
		fail_text: 		'make',
		cost:{
			milk: 		10,
			rennet: 	2,
			salt: 		1,
		},
		unlock_cost:{
			lumber:		5,
			salt: 		10,
			milk: 		100,
		}
	},
	breed_sheep:{
		name: 			'Breed sheep',
		unlock_name: 	'Learn to breed sheep',
		item_id: 		'sheep',
		chance: 		20,
		reward_factor: 	2,
		skill: 			'husbandry',
		action_name: 		'breed',
		fail_text: 		'breed',
		cost:{
			hay_bale:		3,
		},
		unlock_cost:{
			sheep:			2,
			hay_bale: 		20,
		}
	},
	shear_sheep:{
		name: 			'Shear sheep',
		unlock_name: 	'Start sheering sheep',
		item_id: 		'wool',
		chance: 		20,
		skill: 			'husbandry',
		action_name: 	'shear',
		fail_text: 		'shear',
		upgrade_item: 	'sheep',
		unlock_cost:{
			sheep:		5,
		}
	},
	breed_cows:{
		name: 			'Breed cows',
		unlock_name: 	'Learn to breed cows',
		item_id: 		'cow',
		chance: 		20,
		skill: 			'husbandry',
		action_name: 		'breed',
		fail_text: 		'breed',
		cost:{
			hay_bale:		2,
		},
		unlock_cost:{
			cow:			2,
			hay_bale: 		30,
		}
	},
	breed_horses:{
		name: 			'Breed horses',
		unlock_name: 	'Learn to breed horses',
		item_id: 		'horse',
		chance: 		20,
		skill: 			'husbandry',
		action_name: 		'breed',
		fail_text: 		'breed',
		cost:{
			carrot:		5,
			hay_bale:	3,
		},
		unlock_cost:{
			carrot:		100,
			horse:		2,
			hay_bale: 	40
		}
	},
	
	knit_cloth:{
		name: 			'Knit cloth',
		unlock_name: 	'Learn to knit cloth',
		item_id: 		'cloth',
		chance: 		20,
		skill: 			'tailoring',
		action_name: 	'knit',
		fail_text: 		'knit',
		cost:{
			wool:		4,
		},
		unlock_cost:{
			wool: 		15,
		}
	},
	weave_cloth:{
		name: 			'weave cloth',
		unlock_name: 	'Learn to weave twine into cloth',
		item_id: 		'cloth',
		chance: 		20,
		skill: 			'tailoring',
		action_name: 	'weave',
		fail_text: 		'weave',
		cost:{
			twine:		4,
		},
		unlock_cost:{
			twine: 		15,
		}
	},
	wind_twine:{
		name: 			'wind twine',
		unlock_name: 	'Start winding twine',
		item_id: 		'twine',
		chance: 		20,
		skill: 			'tailoring',
		action_name: 	'wind',
		fail_text: 		'wind',
		reward_factor: 	3,
		cost:{
			flax:		10,
		},
		unlock_cost:{
			flax: 		100,
			stone: 		100
		}
	},
	weave_bandage:{
		name: 			'weave bandage',
		unlock_name: 	'Learn to weave bandages',
		item_id: 		'bandage',
		chance: 		20,
		skill: 			'tailoring',
		action_name: 	'weave',
		fail_text: 		'weave',
		cost:{
			cloth:		4,
			parsley: 	5
		},
		unlock_cost:{
			cloth: 		15,
			parsley: 	30
		}
	},
	sew_sack:{
		name: 			'sew sack',
		unlock_name: 	'Learn to sew sacks',
		item_id: 		'sack',
		chance: 		20,
		skill: 			'tailoring',
		action_name: 	'sew',
		fail_text: 		'sew',
		cost:{
			cloth:		1,
		},
		unlock_cost:{
			cloth: 		5,
		}
	},
	sew_pillow:{
		name: 			'sew pillow',
		unlock_name: 	'Learn to sew pillows',
		item_id: 		'pillow',
		chance: 		20,
		skill: 			'tailoring',
		action_name: 	'sew',
		fail_text: 		'sew',
		cost:{
			cloth:		1,
			feather: 	10,
		},
		unlock_cost:{
			sack: 		10,
			feather: 	100
		}
	},
	sew_cloak:{
		name: 			'sew cloak',
		unlock_name: 	'Learn to sew cloaks',
		item_id: 		'cloak',
		chance: 		20,
		skill: 			'tailoring',
		action_name: 	'sew',
		fail_text: 		'sew',
		cost:{
			cloth:		8,
		},
		unlock_cost:{
			cloth: 		25,
		}
	},
	
	tan_leather:{
		name: 			'tan leather',
		unlock_name: 	'Learn to tan leather',
		item_id: 		'leather',
		chance: 		20,
		skill: 			'tailoring',
		action_name: 	'tan',
		fail_text: 		'tan',
		cost:{
			hide:		4,
		},
		unlock_cost:{
			hide: 		15,
		}
	},
	craft_boots:{
		name: 			'craft boots',
		unlock_name: 	'Learn to craft boots',
		item_id: 		'boots',
		chance: 		20,
		skill: 			'tailoring',
		action_name: 	'craft',
		fail_text: 		'craft',
		cost:{
			leather:		5,
		},
		unlock_cost:{
			leather:		15,
		}
	},
	craft_saddle:{
		name: 			'craft saddle',
		unlock_name: 	'Learn to craft saddles',
		item_id: 		'saddle',
		chance: 		20,
		skill: 			'tailoring',
		action_name: 	'craft',
		fail_text: 		'craft',
		cost:{
			leather:		3,
			iron: 			3
		},
		unlock_cost:{
			leather:		15,
			iron: 			15
		}
	},
	hunt_wild_sheep:{
		name: 			'Catch wild livestock',
		unlock_name: 	'Look for some wild livestock',
		bonus_loot:{
			sheep: 		25,
			cow: 		10,
			horse: 		1,
		},
		chance: 		20,
		reward_factor: 	1,
		skill: 			'hunting',
		action_name: 		'hunt',
		fail_text: 		'hunt',
		cost:{
			hay:		3,
		},
		unlock_cost:{
			hay:		25,
		}
	},
	hunt_wolf:{
		name: 			'Hunt wolf',
		unlock_name: 	'Start luring wolves',
		item_id: 		'hide',
		bonus_loot:{
			bone: 		25,
			meat: 		10,
		},
		chance: 		20,
		reward_factor: 	3,
		skill: 			'hunting',
		action_name: 	'hunt',
		fail_text: 		'hunt',
		upgrade_item: 	'hunter',
		cost:{
			arrow: 		1,
			meat:		1,
		},
		unlock_cost:{
			hunter: 	1,
			meat: 		10,
		}
	},
	hunt_wild_animals:{
		name: 			'Hunt wild animals',
		type: 			'combat',
		action_name: 	'attack',
		possible_monsters:{
			0:{
				chance: 	1000,
				monsters:{
				}
			},
			1:{
				chance: 	20,
				monsters:{
					m_hunter:{
						min: 	1,
						max: 	1,
					}
				}
			},
			2:{
				chance: 	25,
				monsters:{
					m_robin: 	{
						min: 	1,
						max: 	1,
					},
				}
			},
			3:{
				chance: 	2,
				monsters:{
					m_brown_bear: 	{
						min: 	1,
						max: 	1,
					},
				}
			},
			4:{
				chance: 	25,
				monsters:{
					m_roe: 	{
						min: 	1,
						max: 	1,
					},
				}
			},
			5:{
				chance: 	100,
				monsters:{
					m_squirrel: 	{
						min: 	3,
						max: 	8,
					},
				}
			},
			
		},
		unlock_cost:{
			hunter:		1,
		}
	},
	hunt_birds:{
		name: 			'Hunt birds',
		unlock_name: 	'Assign a hunter to look for birds',
		item_id: 		'feather',
		bonus_loot:{
			egg: 		5,
			hay: 		5,
			meat: 		1,
		},
		chance: 		20,
		reward_factor: 		4,
		skill: 			'hunting',
		action_name: 		'hunt',
		fail_text: 		'hunt',
		upgrade_item: 		'hunter',
		cost:{
			arrow:		1,
		},
		unlock_cost:{
			hunter:		1,
		}
	},
	hunt_rabbits:{
		name: 			'Hunt rabbits',
		unlock_name: 	'Assign a hunter to look for rabbits',
		bonus_loot:{
			hide: 		100,
			meat: 		1,
			bone: 		1,
		},
		chance: 		20,
		skill: 			'hunting',
		action_name: 		'hunt',
		fail_text: 		'miss',
		upgrade_item: 	'hunter',
		cost:{
			arrow:		1,
		},
		unlock_cost:{
			hunter:		1,
		}
	},
	hunt_boars:{
		name: 			'Hunt boars',
		unlock_name: 	'Assign a hunter to look for boars',
		item_id: 		'meat',
		bonus_loot:{
			hide: 		50,
			bone: 		10,
		},
		chance: 		20,
		reward_factor: 	4,
		skill: 			'hunting',
		action_name: 		'hunt',
		fail_text: 		'hunt',
		upgrade_item: 	'hunter',
		cost:{
			spear:		1,
		},
		unlock_cost:{
			hunter: 	1,
			spear: 		10,
		}
	},
	hunt_deer:{
		name: 			'Hunt deer',
		unlock_name: 	'Assign a hunter to look for deer',
		bonus_loot:{
			meat: 		100,
			hide: 		50,
			bone: 		20,
		},
		chance: 		20,
		skill: 			'hunting',
		action_name: 		'hunt',
		fail_text: 		'miss',
		upgrade_item: 	'hunter',
		cost:{
			arrow:		1,
		},
		unlock_cost:{
			hunter:		1,
		}
	},
	butcher_chickens:{
		name: 			'Butcher chickens',
		unlock_name: 	'Start butchering chickens',
		item_id: 		'meat',
		bonus_loot:{
			feather: 	50,
			bone: 		25
		},
		chance: 		20,
		reward_factor: 	2,
		skill: 			'butchering',
		action_name: 	'butcher',
		fail_text: 		'butcher',
		upgrade_item: 	'knife',
		cost:{
			chicken: 	1,
		},
		unlock_cost:{
			chicken: 	50,
			knife: 		1
		}
	},
	butcher_sheep:{
		name: 			'Butcher sheep',
		unlock_name: 	'Start butchering sheep',
		item_id: 		'meat',
		bonus_loot:{
			bone: 		10
		},
		chance: 		20,
		reward_factor: 	3,
		skill: 			'butchering',
		action_name: 		'butcher',
		fail_text: 		'butcher',
		cost:{
			sheep: 		1,
		},
		unlock_cost:{
			sheep: 		10,
		}
	},
	butcher_cow:{
		name: 			'Butcher cow',
		unlock_name: 	'Start butchering cows',
		item_id: 		'meat',
		chance: 		20,
		bonus_loot:{
			hide: 		100,
			rennet: 	20,
			bone: 		10
		},
		reward_factor: 	3,
		skill: 			'butchering',
		action_name: 		'butcher',
		fail_text: 		'butcher',
		cost:{
			cow: 		1,
		},
		unlock_cost:{
			cow: 		10,
		}
	},
	package_meat:{
		name: 			'Package meat',
		unlock_name: 	'Set up meat packaging',
		item_id: 		'supplies',
		chance: 		25,
		skill: 			'packaging',
		action_name: 		'pack',
		fail_text: 		'pack',
		cost:{
			meat: 			12,
			crate: 			1,
		},
		unlock_cost:{
			meat:  			40,
			crate: 			3,
		}
	},
	cook_onion_rings:{
		name: 			'Cook onion rings',
		unlock_name: 	'Learn to cook onion rings',
		item_id: 		'onion_rings',
		chance: 		20,
		skill: 			'cooking',
		action_name: 		'cook',
		fail_text: 		'cook',
		cost:{
			flour:  	1,
			onion: 		2,
			firewood: 	1
		},
		unlock_cost:{
			flour:  	5,
			onion: 		10,
			firewood: 	5
		}
	},
	cook_tomato_soup:{
		name: 			'Cook tomato soup',
		unlock_name: 	'Learn to cook tomato soup',
		item_id: 		'tomato_soup',
		chance: 		20,
		skill: 			'cooking',
		action_name: 		'cook',
		fail_text: 		'cook',
		cost:{
			tomato:  	3,
			meat: 		3,
			firewood: 	3
		},
		unlock_cost:{
			tomato:  	12,
			meat: 		12,
			firewood: 	12
		}
	},
	cook_hamburger:{
		name: 			'Cook hamburger',
		unlock_name: 	'Learn to cook hamburgers',
		item_id: 		'hamburger',
		chance: 		20,
		skill: 			'cooking',
		action_name: 		'cook',
		fail_text: 		'cook',
		cost:{
			bread:  	1,
			salad: 		1,
			meat: 		1,
			onion: 		1,
			firewood: 	5
		},
		unlock_cost:{
			bread:  	10,
			salad: 		10,
			meat: 		10,
			onion: 		10,
			firewood: 	50
		}
	},
	cook_steak:{
		name: 			'Cook steak',
		unlock_name: 	'Learn to cook steak',
		item_id: 		'steak',
		chance: 		20,
		skill: 			'cooking',
		action_name: 		'cook',
		fail_text: 		'cook',
		cost:{
			meat: 		2,
			firewood: 	2
		},
		unlock_cost:{
			meat: 		20,
			firewood: 	20
		}
	},
	cook_steak_dinner:{
		name: 			'Cook steak dinner',
		unlock_name: 	'Learn to cook steak dinners',
		item_id: 		'steak_dinner',
		chance: 		20,
		skill: 			'cooking',
		action_name: 		'cook',
		fail_text: 		'cook',
		cost:{
			steak: 		2,
			fries: 		4,
			salad: 		5,
		},
		unlock_cost:{
			steak: 		30,
			fries: 		40,
			salad: 		50,
		}
	},
	serve_three_course_dinner:{
		name: 			'Three course dinner',
		unlock_name: 		'Start serving three course dinners',
		item_id: 		'treasure',
		chance: 		20,
		skill: 			'service',
		action_name: 		'serve',
		fail_text: 		'serve',
		cost:{
			tomato_soup: 		3,
			steak_dinner: 		3,
			apple_pie: 			3,
		},
		unlock_cost:{
			tomato_soup: 		5,
			steak_dinner: 		5,
			apple_pie: 			5,
		}
	},
	serve_high_tea:{
		name: 			'High tea',
		unlock_name: 		'Start serving high tea',
		item_id: 		'treasure',
		chance: 		20,
		skill: 			'service',
		action_name: 		'serve',
		fail_text: 		'serve',
		cost:{
			cucumber_sandwich: 		25,
			mint_tea: 				25,
		},
		unlock_cost:{
			cucumber_sandwich: 		50,
			mint_tea: 				50,
		}
	},
}

var available_skills = {};

$.each(available_actions, function(action_id, action_info){
	if(available_skills[action_info['skill']] == undefined && action_info['item_id'] != undefined)
	{
		available_skills[action_info['skill']] = {
			item_id: action_info['item_id']
		};
	}
});