var starting_hp = 25;
var test_mode = true;
var pack_price = 150;
var single_card_price = 100;
var pack_cards_count = 3;
var coins_gained_per_win = 3;
var coins_gained_per_loss = 1;
var max_deck_size = 12;
var phase_hp_factor = 0.5;
var rarity_factor = 3;

var all_cards = {};