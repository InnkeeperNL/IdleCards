All assets are copyright Nikolai Bird 2017

You are allowed to use them freely for any purpose as long as you either make a donation of any amount or give credit and link back.

Paypal donations to: artisu@hotmail.com
Credit and link: Nikolai Bird dicingdangers.com

Need any bespoke work? Contact me : nbird007@gmail.com

:)

Nikolai